Adult with income over 50k-Drop_columns.ipynb
 Drop_columns
 '?' -> 'unknown' 으로 바꿈

Adult with income over 50k.ipynb
 '?' -> 'unknown' 으로 바꿈

두 비교 결과 drop columns 한게더 잘나옴

담당:
임한희 : Feature 분석 -> 각 column 값 분석, ? 값 교체

정희석(조장) : Classifier 분석 및 학습 진행 -> Decision Tree, Random Forest, Logistic Regressio

노정민 : 학습 결과 분석 -> 정확도, 정밀도 재현율 F1 Score, ROC_AUC, 그래프

김민정 : 데이터 전처리 -> Label encoding, Column drop, Standard, MinMaxScaler